To use these images, follow these instructions:

1. Go into your Insaniquarium game folder. You should find a few files including a folder called "images".
2. Go into "images".
3. Paste the inlcuded GIF files into the folder. Overwrite them (don't worry, if you want to have the originals back again, I will include them in a separate subfolder).

Have fun seeing a Big Giant Scuba-Diving Elephant wreak havoc in your tank! ;)
